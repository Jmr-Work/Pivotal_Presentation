/************************************************************************************************************************************/
/** @file		pwm_tw.c
 * 	@brief		TivaWare implementation of PWM Peripheral Usage
 *
 *  @target		TI Tiva TM4C1294NCPDT - Silicon Revision 2
 *	@board		all
 *
 * 	@author		Justin Reina, Firmware Engineer, Misc. Company
 * 	@created	12/8/16
 * 	@last rev	12/21/16
 *
 * 	@section	Opens
 * 			None current
 *
 * 	@section	Legal Disclaimer
 * 			All contents of this source file and/or any other Misc. Product related source files are the explicit property of
 * 			Justin Reina. Do not distribute. Do not copy.
 */
/************************************************************************************************************************************/
#include "pwm_tw.h"


/************************************************************************************************************************************/
/**	@fcn		void tw_sys_init(void)
 *  @brief		Setup the mcu for use
 *
 *  @details	Components
 *  			- clocking system 	(xtal: max)
 *  			- gpio 				(pf2/pf3)
 *  			- pwm				(pwm2/pwm3))
 *
 *  @pre		any
 *  @post		PF2->PWM2		(Pin 44, Port X9.3)
 *  			PF3->PWM3		(Pin 45, Port X9.5)
 *  			both on at 50% of T=XYZms
 *  			SW1, SW2 set to Inputs (PJ.0-1)
 */
/************************************************************************************************************************************/
void tw_sys_init(void) {

	//NVIC
	IntMasterDisable();														/* silence all interrupts								*/

	//Set Clock
	SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_OSC), F_CPU_HZ);


	//******************************************************************************************************************************//
	//	 									  GPIO MODULE INIT (PWM:PF2-3, LED:PN0-1, SW:PJ0-1)										//
	//******************************************************************************************************************************//
	//PWM
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);							/* Enable GPIO Port F									*/

	GPIOPinConfigure(GPIO_PF2_M0PWM2);										/* Set pin-muxes										*/
    GPIOPinConfigure(GPIO_PF3_M0PWM3);

    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_2);							/* Set gpio-modules to push-pull output					*/
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_3);

    //LED
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);							/* Enable GPIO Port N									*/

    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, BIT0|BIT1);						/* Set PN0, PN1 as GPIO-low								*/
    GPIOPinWrite(GPIO_PORTN_BASE, BIT0|BIT1, 0);

    //Switches
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOJ);							/* Enable GPIO Port J									*/
	GPIODirModeSet(GPIO_PORTJ_BASE, (BIT0|BIT1), GPIO_DIR_MODE_IN);
	GPIOPadConfigSet(GPIO_PORTJ_BASE, (BIT0|BIT1), GPIO_STRENGTH_4MA, GPIO_PIN_TYPE_STD_WPU);	/* Weak pull-downs so active-high	*/


    //******************************************************************************************************************************//
    //	 											    PWM MODULE INIT																//
    //******************************************************************************************************************************//
	//Init PWM Module
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);								/* Enable the PWM0 peripheral							*/

    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_PWM0));						/* Wait for the PWM0 module to be ready					*/

    PWMGenConfigure(PWM0_BASE, PWM_GEN_1, 									/* Configure the PWM generator for count down with 		*/
    				PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);				/* With immediate updates to the parameters 			*/

	//Init PWM Gen #1 (holds PWM2[CMPA] & PWM3[CMPB])
    PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, pwmPeriod);						/* Set the period of Generator Module 1 to 20ms			*/
    																		/* PWM1_LOAD set to 20000-1 = 19999						*/

    PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2, pwm2_per);						/* Set the pulse width of PWM2 for a 10ms pulse			*/
    																		/* PWM1_CMPA set to 20-10 = 10000-1 = 9999 				*/

    PWMPulseWidthSet(PWM0_BASE, PWM_OUT_3, pwm3_per);						/* Set the pulse width of PWM3 for a 5ms pulse			*/
    																		/* PWM1_CMPB set to 20-5  = 15000-1  = 14999 			*/

	//Start PWM Module
    PWMGenEnable(PWM0_BASE, PWM_GEN_1);										/* Start the timers in Generator Module 1				*/

    PWMOutputState(PWM0_BASE, (PWM_OUT_2_BIT | PWM_OUT_3_BIT), true);		/* Enable both outputs (PWM2, PWM3)						*/

	return;
}


/************************************************************************************************************************************/
/**	@fcn		void tw_set_pwm(PwmChannel channel, uint32_t value)
 *	@brief		Set a PWM channel's output value
 *
 *  @example	ex - tw_set_pwm(PWM2, 500) <- Set PWM2 to 50%
 *
 *  @param		[in]	(PwmChannel) channel	channel of PWM to use   (e.g. PWM Module0 Unit2 is 'PWM2'
 *  @param		[in]	(uint32_t	 value		PWM value in percentage (e.g. 99.5% is 995)
 *
 *  @pre		Channel requested is properly configured and ready for use
 *  @post		Channel requested is set to value percentage for PWM output
 *
 *  @section	Assumptions
 *  			All input values are valid and correct
 */
/************************************************************************************************************************************/
void tw_set_pwm(PwmChannel channel, uint32_t value) {

	//Convert value(%) to Compare Value
	uint32_t cmpVal = (value*pwmPeriod) / 1000;								/* @val 	(in: 0 - 1000), (out: 0 - pwmPeriod)		*/

	//select pwm channel
	uint32_t pwmOut = (channel==PWM2) ? PWM_OUT_2 : PWM_OUT_3;

	//apply the value
    PWMPulseWidthSet(PWM0_BASE, pwmOut, cmpVal);							/* Set both to 1.0ms pulses								*/

	return;
}

